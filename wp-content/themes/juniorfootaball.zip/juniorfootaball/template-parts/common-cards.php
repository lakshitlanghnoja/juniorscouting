<div class="cardtype_wrapper">
    <div class="container">
        <ul>
            <li><a href=""> <img src="<?php echo get_template_directory_uri(); ?>/images/ideal.png"></a></li>
            <li><a href=""> <img src="<?php echo get_template_directory_uri(); ?>/images/bancontact.png"></a></li>
            <li><a href=""> <img src="<?php echo get_template_directory_uri(); ?>/images/paypal.png"></a></li>
            <li><a href=""> <img src="<?php echo get_template_directory_uri(); ?>/images/mastercard.png"></a></li>
            <li><a href=""> <img src="<?php echo get_template_directory_uri(); ?>/images/visa.png"></a></li>
        </ul>
    </div>
</div>
