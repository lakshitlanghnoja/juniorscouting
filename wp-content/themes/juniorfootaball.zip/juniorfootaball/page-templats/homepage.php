<?php
/* Template Name: Home Page */
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); 
$pageID = get_the_ID();
?>

<div class="container-fluid">
    <div class="row">

    <!-- Carousel -->
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
			<?php 
			$i = 0;
			while(have_rows('slider_details')):the_row(); ?>
                <li data-target="#carousel-example-generic" data-slide-to="<?php echo $i;?>" class="active"></li>
                <?php 
                $i++;
				endwhile;
				?>
            </ol>
            <!-- Wrapper for slides -->
            <div class="carousel-inner">
			<?php 
			if(have_rows('slider_details')){
				while(have_rows('slider_details')):the_row();
				$slidertext = get_sub_field('slider_text',$pageID);
				$sliderimg = get_sub_field('slider_image',$pageID);
				?>
				<div class="item active">
                    <img src="<?php echo $sliderimg['url']; ?>" alt="First slide">
                    <!-- Static Header -->
                    <div class="header-text hidden-xs">
                        <div class="col-md-12 text-center">
                            <h2><strong><?php echo $slidertext; ?></strong>
                            </h2>

                            <div class="">
                                <a class="btn btn-theme btn-sm btn-min-block" href="#">VOOR SPELERS</a>
                                <a class="btn btn-theme btn-sm btn-min-block" href="#">VOOR CLUBS</a></div>
                        </div>
                    </div><!-- /header-text -->
                </div>

							<?php endwhile;
			}?>
			
            </div>
            <!-- Controls -->
            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                <img src="<?php echo get_template_directory_uri(); ?>/images/slider_nav_left.png">
            </a>
            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                <img src="<?php echo get_template_directory_uri(); ?>/images/slider_nav_right.png">
            </a>
        </div><!-- /carousel -->
        
    </div>
</div>
<div class="filter_wrapper home_filter">
    <div class="container">
        <h4>ZOEKEN</h4>
        <form>
            <div class="form-group form-inline">
                <label for="naam">NAAM</label>
                <input type="text" class="form-control name_field" id="naam">
                <label for="LEEFTIJD">LEEFTIJD</label>
                <select class="form-control" id="LEEFTIJD">
                    <option> 6-8 jaar</option>
                    <option> 8-10 jaar</option>
                    <option> 10-14 jaar</option>
                </select>
                <label for="AGENDA">AGENDA</label>
                <select class="form-control" id="AGENDA">
                    <option> January</option>
                    <option> Ferbruary</option>
                    <option> March</option>
                    <option> April</option>
                    <option> May</option>
                    <option> June</option>
                    <option> July</option>
                    <option> August</option>
                    <option> September</option>
                    <option> October</option>
                    <option> November</option>
                    <option> December</option>
                </select>
                <div class=" form-control btn btn-danger login_btn">INLOGGEN</div>
            </div>


        </form>

    </div>
</div>
<div class="middlepart_wrapper">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3 class="header">Wordt nu lid van Junior Scouting</h3>
            </div>

            <div class="col-md-6 leftpart">
                <img class="icon_image" src="<?php echo get_template_directory_uri(); ?>/images/jr_spelers_icon.png"/>
                <h5 class="header">Voor junior spelers</h5>
                <h6>€ 50 / jaar </h6>
                <a class="btn btn-theme btn-sm btn-min-block" href="<?php echo esc_url(get_permalink(get_page_by_path('Player Register Page'))); ?>">Lid worden als speler</a>
                <p class="bodytxt">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget congue sapien.
                    Nunc maximus laoreet quam, in sollicitudin diam dignissim ornare. Integer venenatis arcu venenatis
                    neque rutrum, vel vehicula neque bibendum. Orci varius natoque penatibus et magnis dis parturient
                    montes, nascetur ridiculus mus. Maecenas ligula dolor, sagittis ut mauris sit amet, maximus
                    scelerisque tellus. Praesent et fringilla augue, quis tincidunt est. Ut sed dolor at justo consequat
                    elementum. </p>
                <ul>
                    <li>uitgebreide profielpagina</li>
                    <li>wordt opgemerkt door clubs</li>
                    <li>korting in de webshop</li>
                </ul>
            </div>
            <div class="col-md-6 rightpart">
                <img class="icon_image" src="<?php echo get_template_directory_uri(); ?>/images/voor_clubs_icon.png"/>
                <h5 class="header">Voor clubs</h5>
                <h6>€ 350 / jaar </h6>
                <a class="btn btn-theme btn-sm btn-min-block" href="<?php echo esc_url(get_permalink(get_page_by_path('Club Register Page'))); ?>">Lid worden als club</a>
                <p class="bodytxt">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget congue sapien.
                    Nunc maximus laoreet quam, in sollicitudin diam dignissim ornare. Integer venenatis arcu venenatis
                    neque rutrum, vel vehicula neque bibendum. Orci varius natoque penatibus et magnis dis parturient
                    montes, nascetur ridiculus mus. Maecenas ligula dolor, sagittis ut mauris sit amet, maximus
                    scelerisque tellus. Praesent et fringilla augue, quis tincidunt est. Ut sed dolor at justo consequat
                    elementum. </p>
                <ul>
                    <li>uitgebreide zoekmogelijkheden</li>
                    <li>contacteren van spelers</li>
                    <li>uitgebreide profielpagina</li>
                    <li>korting in de webshop</li>
                </ul>
            </div>
        </div>
    </div>

</div>

<?php 

$commonSponsor = realpath(__DIR__ . '/..').'/template-parts/common-sponsor.php';
$commonCards = realpath(__DIR__ . '/..').'/template-parts/common-cards.php';

if (file_exists($commonSponsor)) {
    // echo "in if";exit;
    require( $commonSponsor );
}
if (file_exists($commonCards)) {
    // echo "in if";exit;
    require( $commonCards );
}

?>

<?php get_footer();
